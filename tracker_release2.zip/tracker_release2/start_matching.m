function [BWmt BWmc BWmd] = start_matching()
cd ..;
[BWmt BWmc BWmd] = start_matching()
end


